package com.example.demo.enumerated;
public enum Role {
    USER, ADMIN;
}
